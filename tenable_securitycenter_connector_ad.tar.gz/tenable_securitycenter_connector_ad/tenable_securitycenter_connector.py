import sys
from tenable_securitycenter_connector import CustomConnector

conn_uuid = sys.argv[1]

if __name__ == '__main__':
    CustomConnector().execute()