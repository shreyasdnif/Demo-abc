#!/bin/bash

echo "Installing virtualenv"
wheel_path="$WORKDIR/connectors/tenable_securitycenter_connector/requirements/pip/"
pip3 install --no-index --find-links=file:"$wheel_path" virtualenv

#inside tool folder
#if [[ ! -e $WORKDIR/connectors/tenable_securitycenter_connector/ ]]; then
echo "creating python3 instance tenable_securitycenter_connector"
cd $WORKDIR/connectors/tenable_securitycenter_connector/
virtualenv -p python3 .


#activate envirnoment
echo "activate virtualenv tenable_securitycenter_connector"
source $WORKDIR/connectors/tenable_securitycenter_connector/bin/activate

echo "Installing required pip3 packages from requirements.txt "
pip3 install --no-index --find-links  "$wheel_path" -r $WORKDIR/connectors/tenable_securitycenter_connector/requirement.txt
