"""
    4 stages of validation
        1.  Configuration   -   steps related to connector configurations loading.
        2.  Connection  -   steps related to database connection.
        3.  Fetch Logs  -   steps related to fetching logs after authentication.
        4.  Validation  -   steps related to validating for getting config in arguments and passing it to validation step.
"""

import os
import json
from utils.logg_helper import get_logger
from utils.cfg_validation_helper import report_validation_status, load_config_from_sys_args
# from utils.connector_functions import remove_files
from utils.signal_helper import TimeoutException
from utils.connector_decorators import set_timeout, at_exit, default_return
import utils.cfg_validation_constants as const
import traceback
logger = get_logger('connector_validate', 1)
validation_messages = []


def exit_callback():
    logger.debug("Clearing things")
    try:
        # remove_files(validation_files)
        pass
    except Exception as e:
        logger.error(f"Clearing things failed: {e}")


@at_exit(exit_callback, exit_signal_callback=True)
@set_timeout(const.GLOBAL_MAX_EXECUTION_TIME)
@default_return((const.SUCCESS, const.SUCCESS_MSG))
def validate_config(cfg):
    logger.debug("Validating configuration")
    try:
        try:

            connector_name = cfg['connector_name']
            log_source = cfg['log_source']
            query = cfg['query']
            field_name = cfg['field_name']
            initial_value = cfg['initial_value']
            connection_mode = list(cfg["connection_mode"].keys())[0]
            connection_string = cfg['connection_mode'][connection_mode]["connection_string"]

            if connection_mode=="jdbc":
                connection_driver = cfg['connection_mode']['jdbc']["connection_driver"]
                user = cfg['connection_mode']['jdbc']["user"]
                password = cfg['connection_mode']['jdbc']["password"]

            logger.info("Configuration received")

            validation_messages.append(json.dumps({'Configuration Stage': const.SUCCESS,
                                                   "status": const.VALIDATION_SUCCESS}))
        except Exception as e:
            logger.error(traceback.format_exc())
            logger.error(": Error while reading config- {}".format(e))
            validation_messages.append(json.dumps({'Configuration Stage': str(e),
                                                   "status": const.FAILED}))
            return const.FAILED, "Configuration Stage:Invalid proxy value"

        try:
            #Assigning the value to alerttype
            if connection_mode == 'odbc':
                import pyodbc
                connection = pyodbc.connect(connection_string)
                logger.info("Connected to the database server by ODBC!")
                
            elif connection_mode == 'jdbc':
                import jaydebeapi
                connector_path="/dnif/connectors/rdbms_connector"
                # Export JDBC driver path to CLASSPATH environment variable
                default_jars = [f"{connector_path}/rdbms_jar/postgresql-42.2.9.jar",
                                f"{connector_path}/rdbms_jar/ojdbc8.jar",
                                f"{connector_path}/rdbms_jar/mysql-connector-java-8.0.21.jar",
                                f"{connector_path}/rdbms_jar/mssql-jdbc-7.4.1.jre11.jar"
                                ]
                os.environ['CLASSPATH'] = ":".join(default_jars)

                connection = jaydebeapi.connect(connection_driver, connection_string, [user, password])
                logger.info("Connected to the database server by JDBC!")
                
                validation_messages.append(json.dumps({'Connection Stage': const.SUCCESS,
                                                   "status": const.VALIDATION_SUCCESS}))
                
        except Exception as e:
            logger.error("Connection failed: Error - {}".format(e))
            validation_messages.append(json.dumps({'Connetcion Stage': str(e),
                                                   "status": const.FAILED}))
            return const.FAILED, "Connection Stage: Unable to connect"

        try:
            cursor = connection.cursor()
            query_vars = dict()
            query_vars['field_name'] = field_name
            query_vars['initial_value'] = initial_value
            query_str = query.format(**query_vars)

            cursor.execute(query_str)
            rows = cursor.fetchall()

            validation_messages.append(json.dumps({'Fetch Logs': const.SUCCESS,
                                                   "status": const.VALIDATION_SUCCESS}))

        except Exception as e:
            logger.error(f"Request Failed: {e}")
            validation_messages.append(json.dumps({'Fetch Logs': f'Log listing error - {str(e)}',
                                                   "status": const.FAILED}))
            return const.FAILED, "Fetch Logs:Unable to connect"

        # if any error occurs log error and return response with error message.
    except TimeoutException as timeout:
        logger.warning("Unable to validate config. validate_config taking too long time to execute! Timeout!")
        validation_messages.append(
            json.dumps({'Validation Stage': f"Validation Stage:Request Timeout - {str(timeout)}",
                        "status": const.FAILED}))
        return const.FAILED, "Validation Stage:Validation Handler Timeout"
    except Exception as e:
        logger.error(f"Unable to validate config: {e}")
        validation_messages.append(json.dumps({'Validation Stage': f"Unknown Error - {str(e)}",
                                               "status": const.FAILED}))
        return const.FAILED, "Validation Stage:An Unknown Error Occurred"


def execute():
    logger.debug("Starting execution")
    try:
        conn_uuid, cfg = load_config_from_sys_args()
        if cfg:
            status, message = validate_config(cfg)
        else:
            status, message = const.FAILED, "Configuration Stage:Configuration Error"
            validation_messages.append(json.dumps({'Configuration Stage': 'Configuration Error - Unable to load config',
                                                   "status": const.FAILED}))
        report_validation_status(conn_uuid, status, validation_messages, message)
    except Exception as e:
        logger.error(f"Validation Stage:{e}")


if __name__ == "__main__":
    execute()