#!/bin/bash

echo "Installing virtualenv"
wheel_path="$WORKDIR/connectors/rdbms_connector/requirements/pip/"
pip3 install --no-index --find-links=file:"$wheel_path" virtualenv

#inside tool folder
#if [[ ! -e $WORKDIR/connectors/rdbms_connector/ ]]; then
echo "creating python3 instance rdbms_connector"
cd $WORKDIR/connectors/rdbms_connector/
virtualenv -p python3 .


#activate envirnoment
echo "activate virtualenv rdbms_connector"
source $WORKDIR/connectors/rdbms_connector/bin/activate

apt_path="$WORKDIR/connectors/rdbms_connector/requirements/apt"

if [[ ! -e /etc/unixODBC ]]; then
  cd $apt_path
  tar -zxvf unixODBC-2.3.4.tar.gz
  cd unixODBC-2.3.4
  ./configure --prefix=/usr --sysconfdir=/etc/unixODBC
  make
  make install
fi

echo "Installing required pip3 packages from requirements.txt "
pip3 install --no-index --find-links  "$wheel_path" -r $WORKDIR/connectors/rdbms_connector/requirement.txt

#set javajdk
mkdir -p /usr/lib/jvm/
tar -xvf $apt_path/openjdk-14_linux-x64_bin.tar.gz -C /usr/lib/jvm/
echo "export JAVA_HOME=/usr/lib/jvm/jdk-14">>/etc/profile.d/jdk14.sh
echo "export PATH=\$PATH:\$JAVA_HOME/bin">>/etc/profile.d/jdk14.sh
mkdir -p /usr/lib/jvm/java-14-openjdk-amd64
cp -r /usr/lib/jvm/jdk-14/* /usr/lib/jvm/java-14-openjdk-amd64/
source /etc/profile.d/jdk14.sh
source /etc/profile


echo "--------------------------------------------------------------------------------------------"
echo "PATH : $PATH"
echo "LD_LIBRARY_PATH : $LD_LIBRARY_PATH"
echo "ODBCSYSINI : $ODBCSYSINI"
echo "--------------------------------------------------------------------------------------------"
