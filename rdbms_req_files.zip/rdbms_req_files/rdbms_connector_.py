import datetime
import os
import sys
import uuid
import orjson
import time
import traceback

from collections import OrderedDict
import ipaddr
import unicodedata
import traceback
from utils import pass_helper as password
from utils.BaseConnector import *
proxy_val = os.environ.get("PROXY")
if proxy_val and proxy_val != "":
    print('proxy found')
    proxy = {
        "https": proxy_val
    }
else:
    proxy = {}

h_obj = hashlib.md5()
h_obj.update("rdbms_connector".encode())

class CustomConnector(BaseConnector):

    def __init__(self):
        self.access_token = ''
        BaseConnector.__init__(self)

        self.query_vars = dict()
        self.query_vars['field_name'] = self.cfg.get('field_name', '')

    def fix_datatype(self,row):
        for key, value in row.items():
            try:
                if key in ['AnalyzerIPV4', 'SourceIPV4', 'TargetIPV4']:
                    if value is not None:
                        row[key] = str(ipaddr.IPv4Address(abs(value)))
                elif key in ['AnalyzerIPV6', 'SourceIPV6', 'TargetIPV6']:
                    if value is not None:
                        row[key] = str(ipaddr.IPv6Address(ipaddr.Bytes(value)))
                elif value is None:
                    row[key] = 'NULL'
                elif type(value) is bytes:
                    row[key] = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore')
                elif type(value) is datetime.datetime:
                    row[key] = value.isoformat()
                elif type(value) is uuid.UUID:
                    row[key] = value.hex
                elif 'java class' in str(type(value)):
                    try:
                        row[key] = value.toString()
                    except:
                        row[key] = value
            except Exception as e:
                self.logger.warning(f"value of '{key}' is not valid. Warning: {e}")
        return row

    def get_connection(self):
        try:
            self.logger.debug("Connecting to the database server..")

            mode = list(self.cfg["connection_mode"].keys())[0]
            if not mode:
                self.logger.error("'connection_mode' not configured")
                self.logger.info("Configure valid connection_mode [odbc, jdbc]")
                sys.exit(0)
                
            connection_string = self.cfg['connection_mode'][mode]["connection_string"]
            connection_string = password.decrypt_pass(connection_string, h_obj.hexdigest())
            

            if not connection_string:
                self.logger.error("'connection_string' not defined ")
                self.logger.info("Specify proper 'connection_string' ")
                raise Exception("'connection_string' not defined ")
            if mode == 'odbc':
                import pyodbc
                connection = pyodbc.connect(connection_string)
                self.logger.info("Connected to the database server by ODBC!")
                return connection
            elif mode == 'jdbc':
                import jaydebeapi
                connector_path="/dnif/connectors/rdbms_connector"
                # Export JDBC driver path to CLASSPATH environment variable
                default_jars = [f"{connector_path}/rdbms_jar/postgresql-42.2.9.jar",
                                f"{connector_path}/rdbms_jar/ojdbc8.jar",
                                f"{connector_path}/rdbms_jar/mysql-connector-java-8.0.21.jar",
                                f"{connector_path}/rdbms_jar/mssql-jdbc-7.4.1.jre11.jar"
                                ]
                os.environ['CLASSPATH'] = ":".join(default_jars)

                connection_driver = self.cfg['connection_mode']['jdbc']["connection_driver"]
                username = self.cfg['connection_mode']['jdbc']["user"]
                password1 = self.cfg['connection_mode']['jdbc']["password"]

                connection_driver = password.decrypt_pass(connection_driver, h_obj.hexdigest())
                username = password.decrypt_pass(username, h_obj.hexdigest())
                password1 = password.decrypt_pass(password1, h_obj.hexdigest())


                if not connection_driver:
                    self.logger.error("'connection_driver' not defined.")
                    self.logger.info("Specify proper 'connection_driver'.")
                    raise Exception("'connection_driver' not defined.")
                elif not username or not password1:
                    self.logger.error("'user' or 'password' not defined")
                    self.logger.info("Specify proper 'user' and 'password'")
                    raise Exception("'user' or 'password' not defined")

                connection = jaydebeapi.connect(connection_driver, connection_string, [username, password1])
                self.logger.info("Connected to the database server by JDBC!")
                return connection
            else:
                self.logger.error(f"Invalid connection_mode '{mode}' configured")
                self.logger.info("Valid connection_mode [odbc, jdbc]")
                sys.exit(0)
        except Exception as e:
            self.logger.error(f"Error in database connectivity : {e}")
            self.logger.error(traceback.format_exc())

    def fetch_log(self,connection,bookmark):
        # global bookmark, query_vars

        try:
            log_data = []

            self.logger.debug("Creating DB cursor")
            cursor = connection.cursor()
            marker_initial_value = self.cfg.get('initial_value', '')

            marker_value = bookmark.get('marker_value', marker_initial_value)

            if not marker_value:
                self.logger.error("'initial_value' not defined.")
                self.logger.info("Specify proper 'initial_value'.")
                raise Exception("'initial_value' not defined.")
            elif not self.query_vars['field_name']:
                self.logger.error("'field_name' not defined.")
                self.logger.info("Specify proper 'field_name'.")
                raise Exception("'field_name' not defined.")

            self.query_vars['initial_value'] = marker_value
            query_str = self.cfg.get('query', '')
            query = query_str.format(**self.query_vars)
            self.logger.debug(f"SQL query : {query}")

            cursor.execute(query)
            self.logger.debug("SQL query executed!")

            rows = cursor.fetchall()
            self.logger.debug("SQL query Result Fetched!")

            if rows is not None:
                desc = [unicodedata.normalize('NFKD', d[0]).encode('ascii', 'ignore') for d in cursor.description]
                key = []
                for i in desc:
                    key.append(i.decode())
                # create list of dictionaries from desc and rows
                count = 0
                for row in rows:
                    count += 1
                    result = self.fix_datatype(dict(zip(key, row)))

                    if count == len(rows):
                        self.logger.info(f"total logs received : {count}")
                        bookmark['marker_value'] = str(result[self.cfg['field_name']])
                        self.write_bookmark(self.bookmarkfile,bookmark)

                    log_data.append(str(result))

                self.logger.debug(f"Log sent till : {self.cfg['field_name']} = {bookmark.get('marker_value', '')}")
            return log_data

        except Exception as e:
            self.logger.error(f"Error in rdbms connector: {e}")
            self.logger.debug(traceback.format_exc())

        finally:
            try:
                cursor.close()
            except:
                self.logger.error("Unable to close cursor")

    def get_logs(self):
        try:
            self.logger.info("config : ")
            self.logger.info(self.cfg)
            if os.path.exists(self.bookmarkfile):
                try:
                    bookmark = self.read_bookmark(self.bookmarkfile)
                    self.logger.debug("Founded bookmark value is {}".format(bookmark))
                except Exception as e:
                    self.report_event()
            else:
                bookmark={}
            connection = self.get_connection()
            if connection:
                backoff=self.cfg.get("backoff_duration", 10)
                while True:
                    logs = self.fetch_log(connection,bookmark)
                    if not logs:
                        self.logger.info(f"No logs to fetch. Sleeping for {self.cfg.get('backoff_duration', 10)} seconds")
                        if isinstance(backoff, str):
                            time.sleep(int(backoff))
                        else:
                            time.sleep(backoff)
                    else:
                        self.logger.debug("Logs received")
                        for raw_log in logs:
                            try:
                                log_event = OrderedDict()
                                log_event['log_source'] = self.cfg.get('log_source', '')
                                log_event.update(ast.literal_eval(raw_log))
                            except Exception as e:
                                self.logger.error(f"Error updating 'log_source' : {e}")
                                self.logger.warning("Skipping log. Check 'raw_log' in DEBUG mode")
                                self.logger.debug(f"raw_log : {raw_log}")
                                
                            self.evt_obj.sendtoevtbuffer(orjson.dumps(raw_log))
                            self.logger.info(f"Log sent to buffer with id {raw_log['id']}")

        except Exception as e:

            self.logger.error("Error in get_logs() function: {}".format(e))
            self.logger.error(traceback.format_exc())
            self.report_event()
            time.sleep(self.cfg.get("backoff_duration", 10))

    def execute(self):
        while True:
            try:
                self.get_logs()
            except Exception as e:
                self.logger.error("error in execute: {}".format(e))
                self.logger.error(traceback.format_exc())
                time.sleep(self.cfg.get("backoff_duration", 10))
                self.report_event()


if __name__ == '__main__':
    d = CustomConnector()
    d.execute()